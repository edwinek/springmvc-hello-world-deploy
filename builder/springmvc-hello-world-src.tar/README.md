# springmvc-hello-world
Yet Another SpringMVC Hello World.
